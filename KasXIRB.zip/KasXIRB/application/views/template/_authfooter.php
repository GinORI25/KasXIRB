 <!-- Vendor JS Files -->
 <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/chart.js/chart.umd.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/echarts/echarts.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/quill/quill.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/js/main.js"></script>

</body>

</html>