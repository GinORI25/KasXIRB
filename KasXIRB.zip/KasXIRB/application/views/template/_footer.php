  <!-- ======= Footer ======= -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>
  <footer id="footer" class="footer" >
    <marquee >
      <div class="">
    <div class="copyright">
      &copy; Copyright <strong><span>Kas buku</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="#">Orvill  <i class="ri-emotion-laugh-fill"></i></a>
    </div>
    </div>
</marquee>
  <!-- Vendor JS Files -->
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/chart.js/chart.umd.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/echarts/echarts.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/quill/quill.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/vendor/php-email-form/validate.js"></script>
  <!-- Template Main JS File -->
  <script src="<?= base_url('assets/NiceAdmin/');?>assets/js/main.js"></script>
  
  
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>
  
  <script>$('#hilang').delay('slow').slideDown('slow').delay(2000).slideUp(600);</script>
</body>

</html>